TwitterCore is provided to support [Digits](https://cocoapods.org/pods/Digits) and [TwitterKit](https://cocoapods.org/pods/TwitterKit).
