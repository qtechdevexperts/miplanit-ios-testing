//
//  PunycodeTests.h
//  PunycodeTests
//
//  Created by Nate Weaver on 3/2/12.
//  Copyright (c) 2012 Derailer. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface PunycodeTests : XCTestCase

@end
