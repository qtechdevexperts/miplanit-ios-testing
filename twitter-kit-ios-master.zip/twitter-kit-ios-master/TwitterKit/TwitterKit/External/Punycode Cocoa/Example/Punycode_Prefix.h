//
// Prefix header for all source files of the 'Punycode' target in the 'Punycode' project
//

#ifdef __OBJC__
#import <Cocoa/Cocoa.h>
#endif
