//
//  main.m
//  Punycode
//
//  Created by Wevah on Wed Feb 02 2005.
//  Copyright (c) 2005 Derailer. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
