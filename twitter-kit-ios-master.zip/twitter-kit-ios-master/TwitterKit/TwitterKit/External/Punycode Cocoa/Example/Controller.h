//
//  Controller.h
//  Punycode
//
//  Created by Wevah on Wed Feb 02 2005.
//  Copyright (c) 2005 Derailer. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface Controller : NSWindowController

- (IBAction)stringToIDNA:(id)sender;
- (IBAction)stringFromIDNA:(id)sender;

@end
